import requests
import json

BASE = 'http://127.0.0.1:5000'
s = requests.Session()
# login
r = s.post(BASE + '/', data={'username':'raphstan','password':'STANLEY1234'})
print('Login:', r.status_code)

r = s.get(BASE + '/rank_students')
print('/rank_students status:', r.status_code)
open('rank_students.html', 'w', encoding='utf-8').write(r.text)
print('Saved rank_students.html ({} bytes)'.format(len(r.text)))

# Also check ranking order by parsing students.json
with open('students.json', 'r', encoding='utf-8') as f:
    students = json.load(f)

# compute ranking locally
ranked = sorted([s for s in students if isinstance(s, dict) and 'average_marks' in s], key=lambda x: x['average_marks'], reverse=True)
print('\nTop ranked students:')
for i, s in enumerate(ranked[:10], start=1):
    print(f"{i}. {s.get('student_id')} - {s.get('first_name')} - avg {s.get('average_marks')}")

# Save local ranking to file
open('ranked.json', 'w', encoding='utf-8').write(json.dumps(ranked, indent=2))
print('\nSaved ranked.json')
