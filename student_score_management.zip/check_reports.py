import requests

BASE = 'http://127.0.0.1:5000'
S = requests.Session()

# Login
r = S.post(BASE + '/', data={'username':'raphstan','password':'STANLEY1234'})
print('Login:', r.status_code)

# All students report
r = S.get(BASE + '/reports/all_students')
print('/reports/all_students:', r.status_code)
open('reports_all_students.html', 'w', encoding='utf-8').write(r.text)
print('Saved reports_all_students.html ({} bytes)'.format(len(r.text)))

# Export summary CSV
r = S.get(BASE + '/reports/export_csv')
print('/reports/export_csv:', r.status_code, 'Content-Type:', r.headers.get('Content-Type'))
open('students_summary.csv', 'wb').write(r.content)
print('Saved students_summary.csv ({} bytes)'.format(len(r.content)))
print('Preview (first 200 chars):')
print(r.text[:200])

# Export detailed CSV
r = S.get(BASE + '/reports/export_detailed_csv')
print('/reports/export_detailed_csv:', r.status_code, 'Content-Type:', r.headers.get('Content-Type'))
open('students_detailed.csv', 'wb').write(r.content)
print('Saved students_detailed.csv ({} bytes)'.format(len(r.content)))
print('Preview (first 200 chars):')
print(r.text[:200])
