import time
import json

# ensure requests available
try:
    import requests
except Exception:
    import subprocess, sys
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'requests'])
    import requests

BASE = 'http://127.0.0.1:5000'

s = requests.Session()

# 1) Login
print('Logging in...')
r = s.post(BASE + '/', data={'username': 'raphstan', 'password': 'STANLEY1234'})
print('Login status:', r.status_code)

# 2) Add student (step 1)
student = {
    'student_id': 'S001',
    'firstname': 'Testy',
    'classname': 'JSS1',
    'number_of_subject': '2',
    'subjects': 'Math,English'
}
print('Submitting student basic info...')
r = s.post(BASE + '/add_student', data=student, allow_redirects=False)
print('Add student response code:', r.status_code, 'Location:', r.headers.get('Location'))

# 3) Wait a moment and post scores
time.sleep(0.5)
print('Posting scores...')
scores = {
    'test1_0': '8', 'test2_0': '7', 'test3_0': '9', 'obj_exam_0': '25', 'theory_exam_0': '35',
    'test1_1': '6', 'test2_1': '7', 'test3_1': '8', 'obj_exam_1': '20', 'theory_exam_1': '30'
}
r = s.post(BASE + '/enter_scores', data=scores, allow_redirects=False)
print('Enter scores response code:', r.status_code, 'Location:', r.headers.get('Location'))

# 4) Read students.json
time.sleep(0.2)
print('\nChecking students.json...')
with open('students.json', 'r') as f:
    data = json.load(f)
print('Total students:', len(data))
print('Last student summary:')
print(json.dumps(data[-1], indent=2))

# 5) Cleanup: remove test student if needed
print('\nTest completed.')





