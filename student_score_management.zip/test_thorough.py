import time
import json
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Setup session with retries
s = requests.Session()
retry = Retry(total=5, backoff_factor=1, status_forcelist=[500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retry)
s.mount('http://', adapter)
s.mount('https://', adapter)

BASE = 'http://127.0.0.1:5000'

def test_signup_login():
    print('=== Testing Signup and Login ===')
    # Signup
    signup_data = {
        'username': 'thoroughuser',
        'password': 'thoroughpass',
        'confirm_password': 'thoroughpass'
    }
    r = s.post(BASE + '/signup', data=signup_data, allow_redirects=False)
    print('Signup status:', r.status_code)
    assert r.status_code == 302, f"Signup failed: {r.status_code}"

    # Login
    login_data = {
        'username': 'thoroughuser',
        'password': 'thoroughpass'
    }
    r = s.post(BASE + '/', data=login_data, allow_redirects=False)
    print('Login status:', r.status_code)
    assert r.status_code == 302, f"Login failed: {r.status_code}"
    print('Signup and login successful\n')

def test_add_student():
    print('=== Testing Add Student ===')
    student = {
        'student_id': 'T001',
        'firstname': 'Thorough',
        'classname': 'JSS1',
        'number_of_subject': '2',
        'subjects': 'Math,English'
    }
    r = s.post(BASE + '/add_student', data=student, allow_redirects=False)
    print('Add student response code:', r.status_code)
    assert r.status_code == 302, f"Add student failed: {r.status_code}"

    # Enter scores
    scores = {
        'test1_0': '9', 'test2_0': '8', 'test3_0': '10', 'obj_exam_0': '28', 'theory_exam_0': '38',
        'test1_1': '7', 'test2_1': '8', 'test3_1': '9', 'obj_exam_1': '22', 'theory_exam_1': '32'
    }
    r = s.post(BASE + '/enter_scores', data=scores, allow_redirects=False)
    print('Enter scores response code:', r.status_code)
    assert r.status_code == 302, f"Enter scores failed: {r.status_code}"
    print('Student added successfully\n')

def test_view_students():
    print('=== Testing View Students ===')
    r = s.get(BASE + '/view_students')
    print('View students status:', r.status_code)
    assert r.status_code == 200, f"View students failed: {r.status_code}"
    assert 'Thorough' in r.text, "Student not found in view"
    print('View students successful\n')

def test_search_student():
    print('=== Testing Search Student ===')
    search_data = {'student_id': 'T001'}
    r = s.post(BASE + '/search_student', data=search_data)
    print('Search student status:', r.status_code)
    assert r.status_code == 200, f"Search student failed: {r.status_code}"
    assert 'Thorough' in r.text, "Student not found in search"
    print('Search student successful\n')

def test_edit_student():
    print('=== Testing Edit Student ===')
    edit_data = {
        'student_id': 'T001',
        'firstname': 'ThoroughEdited',
        'classname': 'JSS2',
        'status': 'Passed'
    }
    r = s.post(BASE + '/edit_student', data=edit_data, allow_redirects=False)
    print('Edit student response code:', r.status_code)
    assert r.status_code == 302, f"Edit student failed: {r.status_code}"
    print('Student edited successfully\n')

def test_rank_students():
    print('=== Testing Rank Students ===')
    r = s.get(BASE + '/rank_students')
    print('Rank students status:', r.status_code)
    assert r.status_code == 200, f"Rank students failed: {r.status_code}"
    assert 'ThoroughEdited' in r.text, "Student not found in ranking"
    print('Rank students successful\n')

def test_reports():
    print('=== Testing Reports ===')
    # All students report
    r = s.get(BASE + '/reports/all_students')
    print('All students report status:', r.status_code)
    assert r.status_code == 200, f"All students report failed: {r.status_code}"

    # Individual student report
    r = s.get(BASE + '/student/T001')
    print('Student report status:', r.status_code)
    assert r.status_code == 200, f"Student report failed: {r.status_code}"

    # CSV export
    r = s.get(BASE + '/reports/export_csv')
    print('CSV export status:', r.status_code)
    assert r.status_code == 200, f"CSV export failed: {r.status_code}"

    # Detailed CSV export
    r = s.get(BASE + '/reports/export_detailed_csv')
    print('Detailed CSV export status:', r.status_code)
    assert r.status_code == 200, f"Detailed CSV export failed: {r.status_code}"

    # Rank CSV export
    r = s.get(BASE + '/reports/export_rank_csv')
    print('Rank CSV export status:', r.status_code)
    assert r.status_code == 200, f"Rank CSV export failed: {r.status_code}"

    print('Reports testing successful\n')

def test_error_handling():
    print('=== Testing Error Handling ===')
    # Try to add student with duplicate ID
    student = {
        'student_id': 'T001',  # Duplicate
        'firstname': 'Duplicate',
        'classname': 'JSS1',
        'number_of_subject': '1',
        'subjects': 'Math'
    }
    r = s.post(BASE + '/add_student', data=student, allow_redirects=False)
    print('Duplicate student add response code:', r.status_code)
    # Should redirect back or show error, but not crash
    assert r.status_code in [200, 302], f"Unexpected response for duplicate: {r.status_code}"

    # Invalid scores
    scores = {
        'test1_0': '15',  # Invalid score >10
    }
    r = s.post(BASE + '/enter_scores', data=scores, allow_redirects=False)
    print('Invalid scores response code:', r.status_code)
    assert r.status_code in [200, 302], f"Unexpected response for invalid scores: {r.status_code}"

    print('Error handling testing successful\n')

def test_logout():
    print('=== Testing Logout ===')
    r = s.get(BASE + '/logout', allow_redirects=False)
    print('Logout status:', r.status_code)
    assert r.status_code == 302, f"Logout failed: {r.status_code}"

    # Try to access protected page after logout
    r = s.get(BASE + '/menu', allow_redirects=False)
    print('Access after logout status:', r.status_code)
    assert r.status_code == 302, f"Should redirect after logout: {r.status_code}"
    print('Logout successful\n')

def test_multiple_users():
    print('=== Testing Multiple Users ===')
    # Login as different user
    login_data = {
        'username': 'testuser',  # From previous test
        'password': 'testpass'
    }
    r = s.post(BASE + '/', data=login_data, allow_redirects=False)
    print('Login as different user status:', r.status_code)
    assert r.status_code == 302, f"Login as different user failed: {r.status_code}"

    # Check that this user doesn't see the other user's data
    r = s.get(BASE + '/view_students')
    assert 'ThoroughEdited' not in r.text, "Data leakage between users detected"
    assert 'NewTest' in r.text, "User's own data not visible"

    print('Multiple users isolation successful\n')

if __name__ == '__main__':
    try:
        test_signup_login()
        test_add_student()
        test_view_students()
        test_search_student()
        test_edit_student()
        test_rank_students()
        test_reports()
        test_error_handling()
        test_logout()
        test_multiple_users()
        print('=== ALL TESTS PASSED ===')
    except Exception as e:
        print(f'TEST FAILED: {e}')
        raise
