import pytest
from student_scor import app, students

@pytest.fixture
def client(monkeypatch, tmp_path):
    # Prevent writes to real students.json during tests
    monkeypatch.setattr('student_scor.save_to_json', lambda s, filename='students.json': open(tmp_path / 'students_out.json', 'w').write('ok'))
    # start with a copy of original students in memory to avoid global pollution
    orig = list(students)
    try:
        with app.test_client() as c:
            yield c
    finally:
        students[:] = orig
