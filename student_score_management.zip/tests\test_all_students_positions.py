def test_all_students_report_shows_positions(client):
    client.post('/', data={'username':'raphstan','password':'STANLEY1234'})
    rv = client.get('/reports/all_students')
    assert rv.status_code == 200
    text = rv.data.decode()
    # Check SS2 class: expect 21/1/522 Position 1 out of 2
    assert 'Position: 1 out of 2 in class SS2' in text
    # Header should also show Rank: 1/2 for top student
    assert 'Rank: 1/2' in text
    # Check JSS1 class: S001 Position 1 out of 1
    assert 'Position: 1 out of 1 in class JSS1' in text
