def test_export_rank_csv_requires_login(client):
    rv = client.get('/reports/export_rank_csv')
    assert rv.status_code in (302, 401)

def test_export_rank_csv_logged_in(client):
    client.post('/', data={'username':'raphstan','password':'STANLEY1234'})
    rv = client.get('/reports/export_rank_csv')
    assert rv.status_code == 200
    assert rv.headers['Content-Type'].startswith('text/csv')
    assert b'class_name,position,student_id,first_name' in rv.data

def test_export_rank_csv_filtered(client):
    client.post('/', data={'username':'raphstan','password':'STANLEY1234'})
    rv = client.get('/reports/export_rank_csv?class=SS2')
    assert rv.status_code == 200
    # every non-header line should start with the class filter
    lines = rv.data.decode().splitlines()
    assert lines[0].startswith('class_name')
    for ln in lines[1:]:
        assert ln.startswith('SS2')
