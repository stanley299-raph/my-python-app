def test_export_rank_xlsx_requires_login(client):
    rv = client.get('/reports/export_rank_xlsx')
    assert rv.status_code in (302, 401)


def test_export_rank_xlsx_logged_in(client):
    client.post('/', data={'username':'raphstan','password':'STANLEY1234'})
    rv = client.get('/reports/export_rank_xlsx')
    assert rv.status_code == 200
    ctype = rv.headers.get('Content-Type','')
    assert 'application/vnd.openxmlformats-officedocument' in ctype
    # xlsx is a zip file and should start with PK
    assert rv.data[:2] == b'PK'


def test_export_rank_xlsx_filtered(client):
    client.post('/', data={'username':'raphstan','password':'STANLEY1234'})
    rv = client.get('/reports/export_rank_xlsx?class=SS2')
    assert rv.status_code == 200
    assert rv.data[:2] == b'PK'
