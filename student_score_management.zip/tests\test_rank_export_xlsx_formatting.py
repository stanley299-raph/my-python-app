from io import BytesIO
from openpyxl import load_workbook


def test_xlsx_header_and_widths(client):
    client.post('/', data={'username':'raphstan','password':'STANLEY1234'})
    rv = client.get('/reports/export_rank_xlsx')
    assert rv.status_code == 200
    wb = load_workbook(BytesIO(rv.data))
    ws = wb.active
    # Header checks
    assert ws['A1'].value == 'class_name'
    assert ws['A1'].font.bold is True
    assert ws['B1'].value == 'position'
    assert ws['B1'].font.bold is True
    # If data rows exist ensure B2 is numeric
    if ws.max_row >= 2:
        assert isinstance(ws['B2'].value, (int, float)) or ws['B2'].value is not None
    # Column widths set
    assert ws.column_dimensions['A'].width is not None
    assert ws.column_dimensions['E'].width is not None
    # Data type check for average (E2 should be numeric if present)
    if ws.max_row >= 2:
        cell = ws['E2']
        assert cell.value is not None
        assert isinstance(cell.value, (int, float))
