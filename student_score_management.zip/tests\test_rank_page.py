def test_rank_students_page_orders_students(client):
    # login
    client.post('/', data={'username':'raphstan','password':'STANLEY1234'})
    rv = client.get('/rank_students')
    assert rv.status_code == 200
    text = rv.data.decode()
    # Expect the first class section to contain top students in descending order
    # Check ordering of known student ids in the rendered HTML
    # Find positions
    p1 = text.find('21/1/522')
    p2 = text.find('21/1/520')
    p3 = text.find('S001')
    assert p1 != -1 and p2 != -1 and p3 != -1
    # Ensure SS2 section lists 21/1/522 before 21/1/520
    class_marker = '<div class="class-title">SS2</div>'
    idx = text.find(class_marker)
    assert idx != -1
    segment = text[idx:]
    assert segment.find('21/1/522') < segment.find('21/1/520')
