def test_all_students_report_requires_login(client):
    # not logged in session should redirect
    rv = client.get('/reports/all_students')
    assert rv.status_code in (302, 401, 302)

def test_all_students_report_logged_in(client):
    # login first
    client.post('/', data={'username':'raphstan','password':'STANLEY1234'})
    rv = client.get('/reports/all_students')
    assert rv.status_code == 200
    assert b'All Students Report' in rv.data

def test_export_csv_logged_in(client):
    client.post('/', data={'username':'raphstan','password':'STANLEY1234'})
    rv = client.get('/reports/export_csv')
    assert rv.status_code == 200
    assert rv.headers['Content-Type'].startswith('text/csv')
    assert b'student_id,first_name' in rv.data

def test_export_detailed_csv_logged_in(client):
    client.post('/', data={'username':'raphstan','password':'STANLEY1234'})
    rv = client.get('/reports/export_detailed_csv')
    assert rv.status_code == 200
    assert rv.headers['Content-Type'].startswith('text/csv')
    assert b'student_id,first_name,class_name,subject' in rv.data
