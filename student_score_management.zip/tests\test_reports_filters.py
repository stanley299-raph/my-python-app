def test_export_csv_filtered_by_class(client):
    client.post('/', data={'username':'raphstan','password':'STANLEY1234'})
    rv = client.get('/reports/export_csv?class=SS2')
    assert rv.status_code == 200
    assert b'Stanley' in rv.data
    assert b'S001' not in rv.data or b'S001' in rv.data  # at least no error

def test_export_detailed_csv_filtered_by_student(client):
    client.post('/', data={'username':'raphstan','password':'STANLEY1234'})
    # use one of existing students
    sid = '21/1/522'
    rv = client.get(f'/reports/export_detailed_csv?student_id={sid}')
    assert rv.status_code == 200
    assert sid.encode() in rv.data
    # ensure only rows for that student appear
    lines = rv.data.decode().splitlines()
    for ln in lines[1:]:
        assert ln.startswith(sid)

def test_all_students_report_filter_page(client):
    client.post('/', data={'username':'raphstan','password':'STANLEY1234'})
    rv = client.get('/reports/all_students?class=SS2')
    assert rv.status_code == 200
    assert b'All Students Report' in rv.data
    assert b'SS2' in rv.data
