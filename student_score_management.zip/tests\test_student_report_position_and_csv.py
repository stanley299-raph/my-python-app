def test_student_report_shows_position(client):
    client.post('/', data={'username':'raphstan','password':'STANLEY1234'})
    rv = client.get('/student/21/1/522')
    assert rv.status_code == 200
    text = rv.data.decode()
    assert 'Position:' in text
    assert 'Position: 1 out of' in text


def test_summary_csv_includes_position(client):
    client.post('/', data={'username':'raphstan','password':'STANLEY1234'})
    rv = client.get('/reports/export_csv')
    assert rv.status_code == 200
    text = rv.data.decode()
    assert 'position_in_class' in text
    assert 'class_size' in text


def test_detailed_csv_includes_position(client):
    client.post('/', data={'username':'raphstan','password':'STANLEY1234'})
    rv = client.get('/reports/export_detailed_csv')
    assert rv.status_code == 200
    text = rv.data.decode()
    assert 'position_in_class' in text
    assert 'class_size' in text
