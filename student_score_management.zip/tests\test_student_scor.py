import os
import json
import pytest
from student_scor import app, students, find_student_id, id_exists, load_from_json

@pytest.fixture(autouse=True)
def client(monkeypatch, tmp_path):
    # prevent actual file writes during tests
    monkeypatch.setattr('student_scor.save_to_json', lambda s, filename='students.json': open(tmp_path / 'students_out.json', 'w').write('ok'))
    with app.test_client() as c:
        yield c

def test_find_student_case_insensitive():
    # Ensure S001 exists from previous manual test
    s = find_student_id(students, 's001')
    assert s is not None
    assert s['student_id'].upper() == 'S001'

def test_id_exists_true():
    assert id_exists(students, 's001')

def test_load_from_invalid_json(tmp_path):
    f = tmp_path / 'bad.json'
    f.write_text('not a json')
    assert load_from_json(str(f)) == []

def test_add_student_flow(client):
    # Login
    rv = client.post('/', data={'username': 'raphstan', 'password': 'STANLEY1234'})
    assert rv.status_code in (200, 302)
    # Add a fake student S002
    rv = client.post('/add_student', data={'student_id': 'S002', 'firstname': 'Auto', 'classname': 'T1', 'number_of_subject': '1', 'subjects': 'Sub1'}, follow_redirects=False)
    assert rv.status_code == 302 and '/enter_scores' in rv.headers.get('Location', '')
    # Post scores
    rv = client.post('/enter_scores', data={'test1_0': '10','test2_0':'10','test3_0':'10','obj_exam_0':'30','theory_exam_0':'40'}, follow_redirects=True)
    assert rv.status_code == 200
    # Check student in memory
    s = find_student_id(students, 'S002')
    assert s is not None
    assert s['average_marks'] == 100.0
    # cleanup
    students[:] = [x for x in students if x.get('student_id') != 'S002']
